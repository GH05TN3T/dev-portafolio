# Animated Hover Disclosures

A Pen created on CodePen.

Original URL: [https://codepen.io/Blue-Davinci/pen/oggJGbM](https://codepen.io/Blue-Davinci/pen/oggJGbM).

